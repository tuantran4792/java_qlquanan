package Model;

import POJO_entities.SoSaleorder;
import POJO_entities.SoSaleorderDetail;

public class OrderModel {

	  public SoSaleorder saleOrder ;
	  public SoSaleorderDetail orderDetail;

}
