package Model;

public class Common {

	public class CodePrefix
    {
        public final String SaleOrder = "PX";
        public final String ReceiptVoucher = "PT";
        public final String DraftSaleOrder = "TX";
        public final String DraftReceiptVoucher = "TT";
    }

}
